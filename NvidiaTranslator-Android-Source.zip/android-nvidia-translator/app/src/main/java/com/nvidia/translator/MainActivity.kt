package com.nvidia.translator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

// ─── Colors ──────────────────────────────────────────────────────────────────
val NvidiaGreen  = Color(0xFF76B900)
val DarkBG       = Color(0xFF0A0A0A)
val CardBG       = Color(0xFF141414)
val BorderColor  = Color(0xFF2A2A2A)
val TextPrimary  = Color(0xFFEEEEEE)
val TextSecondary= Color(0xFF888888)

// ─── ViewModel ───────────────────────────────────────────────────────────────
class TranslatorViewModel : ViewModel() {

    // Replace with your NVIDIA NIM API key from https://build.nvidia.com
    private val API_KEY = "YOUR_NVIDIA_API_KEY_HERE"
    private val BASE_URL = "https://integrate.api.nvidia.com/v1/chat/completions"
    private val MODEL   = "meta/llama-3.3-70b-instruct"

    var inputText   by mutableStateOf("")
    var outputText  by mutableStateOf("")
    var isLoading   by mutableStateOf(false)
    var errorMsg    by mutableStateOf<String?>(null)
    var sourceLang  by mutableStateOf("English")
    var targetLang  by mutableStateOf("French")

    val languages = listOf(
        "English","French","Arabic","Spanish","German","Italian",
        "Portuguese","Russian","Chinese","Japanese","Korean",
        "Dutch","Turkish","Polish","Swedish","Darija (Moroccan)"
    )

    fun swapLanguages() {
        val tmp = sourceLang; sourceLang = targetLang; targetLang = tmp
        val tmpText = inputText; inputText = outputText; outputText = tmpText
    }

    fun translate() {
        if (inputText.isBlank()) return
        viewModelScope.launch {
            isLoading = true; errorMsg = null
            try {
                val client = OkHttpClient()
                val prompt = """Translate the following text from $sourceLang to $targetLang.
Return ONLY the translated text with no explanation, no quotes, no labels.

Text to translate:
$inputText"""

                val json = JSONObject().apply {
                    put("model", MODEL)
                    put("max_tokens", 1024)
                    put("messages", JSONArray().apply {
                        put(JSONObject().apply {
                            put("role","system")
                            put("content","You are a professional translator. Return only the translation, nothing else.")
                        })
                        put(JSONObject().apply {
                            put("role","user")
                            put("content", prompt)
                        })
                    })
                }

                val request = Request.Builder()
                    .url(BASE_URL)
                    .addHeader("Authorization","Bearer $API_KEY")
                    .addHeader("Content-Type","application/json")
                    .post(json.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                val response = client.newCall(request).execute()
                val body = response.body?.string() ?: throw Exception("Empty response")
                val parsed = JSONObject(body)
                outputText = parsed
                    .getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .getString("content")
                    .trim()
            } catch (e: Exception) {
                errorMsg = "Error: ${e.message}"
            } finally {
                isLoading = false
            }
        }
    }
}

// ─── Main Activity ────────────────────────────────────────────────────────────
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                TranslatorScreen()
            }
        }
    }
}

// ─── UI ───────────────────────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TranslatorScreen(vm: TranslatorViewModel = viewModel()) {
    Box(
        Modifier
            .fillMaxSize()
            .background(DarkBG)
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Header
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(8.dp)
                        .background(NvidiaGreen, RoundedCornerShape(50))
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    "NVIDIA TRANSLATE",
                    color = NvidiaGreen,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 3.sp
                )
            }
            Text(
                "AI Translator",
                color = TextPrimary,
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
            )

            // Language selector row
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                LanguageDropdown(
                    label = "From",
                    selected = vm.sourceLang,
                    options = vm.languages,
                    onSelect = { vm.sourceLang = it },
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = { vm.swapLanguages() },
                    modifier = Modifier
                        .padding(horizontal = 8.dp)
                        .background(CardBG, RoundedCornerShape(8.dp))
                        .border(1.dp, BorderColor, RoundedCornerShape(8.dp))
                ) {
                    Icon(Icons.Default.SwapHoriz, contentDescription = "Swap", tint = NvidiaGreen)
                }
                LanguageDropdown(
                    label = "To",
                    selected = vm.targetLang,
                    options = vm.languages,
                    onSelect = { vm.targetLang = it },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(Modifier.height(16.dp))

            // Input card
            TranslatorCard(
                title = "Input",
                value = vm.inputText,
                onValueChange = { vm.inputText = it },
                editable = true,
                placeholder = "Enter text to translate…"
            )

            Spacer(Modifier.height(12.dp))

            // Translate button
            Button(
                onClick = { vm.translate() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                enabled = !vm.isLoading && vm.inputText.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = NvidiaGreen),
                shape = RoundedCornerShape(10.dp)
            ) {
                if (vm.isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = Color.Black,
                        strokeWidth = 2.dp
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("Translating…", color = Color.Black, fontWeight = FontWeight.Bold)
                } else {
                    Text("▶  Translate", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }

            Spacer(Modifier.height(12.dp))

            // Output card
            TranslatorCard(
                title = "Translation",
                value = vm.outputText,
                onValueChange = {},
                editable = false,
                placeholder = "Translation will appear here…"
            )

            // Error
            vm.errorMsg?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = Color(0xFFFF4444), fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace)
            }

            Spacer(Modifier.height(24.dp))
            Text(
                "Powered by NVIDIA NIM • ${TranslatorViewModel().MODEL.replace("meta/","")}",
                color = TextSecondary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun TranslatorCard(
    title: String,
    value: String,
    onValueChange: (String) -> Unit,
    editable: Boolean,
    placeholder: String
) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CardBG)
            .border(1.dp, BorderColor, RoundedCornerShape(12.dp))
            .padding(16.dp)
    ) {
        Text(title, color = TextSecondary, fontSize = 11.sp,
            fontFamily = FontFamily.Monospace, letterSpacing = 2.sp)
        Spacer(Modifier.height(8.dp))
        if (editable) {
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 120.dp),
                textStyle = LocalTextStyle.current.copy(color = TextPrimary, fontSize = 15.sp),
                decorationBox = { inner ->
                    if (value.isEmpty()) Text(placeholder, color = TextSecondary, fontSize = 15.sp)
                    inner()
                }
            )
        } else {
            Text(
                if (value.isNotBlank()) value else placeholder,
                color = if (value.isNotBlank()) TextPrimary else TextSecondary,
                fontSize = 15.sp,
                modifier = Modifier.defaultMinSize(minHeight = 120.dp)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LanguageDropdown(
    label: String,
    selected: String,
    options: List<String>,
    onSelect: (String) -> Unit,
    modifier: Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }, modifier = modifier) {
        Column {
            Text(label, color = TextSecondary, fontSize = 11.sp,
                fontFamily = FontFamily.Monospace, letterSpacing = 2.sp)
            OutlinedTextField(
                value = selected,
                onValueChange = {},
                readOnly = true,
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedBorderColor = NvidiaGreen,
                    unfocusedBorderColor = BorderColor,
                    focusedContainerColor = CardBG,
                    unfocusedContainerColor = CardBG
                ),
                modifier = Modifier.menuAnchor().fillMaxWidth(),
                textStyle = LocalTextStyle.current.copy(fontSize = 13.sp)
            )
        }
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(CardBG)
        ) {
            options.forEach {
                DropdownMenuItem(
                    text = { Text(it, color = TextPrimary, fontSize = 13.sp) },
                    onClick = { onSelect(it); expanded = false }
                )
            }
        }
    }
}
